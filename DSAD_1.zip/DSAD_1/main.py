# Python3 implementation of Min Heap
from datetime import *
import sys
from itertools import islice


class MinHeap:

    def __init__(self, maxsize):
        self.maxsize = maxsize
        self.size = 0
        self.Heap = [0] * (self.maxsize + 1)
        self.Heap[0] = -1 * sys.maxsize
        self.FRONT = 1

    # Function to return the position of
    # parent for the node currently
    # at pos
    def parent(self, pos):
        return pos // 2

    # Function to return the position of
    # the left child for the node currently
    # at pos
    def leftChild(self, pos):
        return 2 * pos

    # Function to return the position of
    # the right child for the node currently
    # at pos
    def rightChild(self, pos):
        return (2 * pos) + 1

    # Function that returns true if the passed
    # node is a leaf node
    def isLeaf(self, pos):
        return pos * 2 > self.size

    # Function to swap two nodes of the heap
    def swap(self, fpos, spos):
        self.Heap[fpos], self.Heap[spos] = self.Heap[spos], self.Heap[fpos]

    # Function to heapify the node at pos
    def minHeapify(self, pos):

        # If the node is a non-leaf node and greater
        # than any of its child
        if not self.isLeaf(pos):

           ## print("self Heap " + str(self.Heap[pos]))
           # print("self left child " + str(self.leftChild(pos)))
           # print("self heap " + str(self.Heap[self.leftChild(pos)]))
           # print("self Right child " + str(self.rightChild(pos)))
           # print("self heap " + str(self.Heap[self.rightChild(pos)]))
            if isinstance(self.Heap[self.leftChild(pos)], date) and isinstance(self.Heap[self.rightChild(pos)], date):
                if (self.Heap[pos] > self.Heap[self.leftChild(pos)] or self.Heap[pos] > self.Heap[self.rightChild(pos)]):

                    # Swap with the left child and heapify
                    # the left child
                    if self.Heap[self.leftChild(pos)] < self.Heap[self.rightChild(pos)]:
                        self.swap(pos, self.leftChild(pos))
                        self.minHeapify(self.leftChild(pos))

                    # Swap with the right child and heapify
                    # the right child
                    else:
                        self.swap(pos, self.rightChild(pos))
                        self.minHeapify(self.rightChild(pos))

    # Function to insert a node into the heap
    def insert(self, element):
        if self.size >= self.maxsize:
            return
        self.size += 1
        self.Heap[self.size] = element


        current = self.size
        print("Printing variable details")
        print(current)
        print(self.Heap[current])
        print(self.parent(current))
        print(self.Heap[self.parent(current)])
        print("END of PRINTING")

        if current > 1 and isinstance(self.Heap[self.parent(current)], date) and isinstance(self.Heap[current], date):
            while self.Heap[current] < self.Heap[self.parent(current)]:
                self.swap(current, self.parent(current))
                current = self.parent(current)

    # Function to print the contents of the heap
    def Print(self):
        for i in range(1, (self.size // 2) + 1):
            print(" PARENT : " + str(self.Heap[i]) + " LEFT CHILD : " +
                  str(self.Heap[2 * i]) + " RIGHT CHILD : " +
                  str(self.Heap[2 * i + 1]))

    # Function to build the min heap using
    # the minHeapify function
    def minHeap(self):

        for pos in range(self.size // 2, 0, -1):
            self.minHeapify(pos)

    # Function to remove and return the minimum
    # element from the heap
    def remove(self):

        popped = self.Heap[self.FRONT]
        self.Heap[self.FRONT] = self.Heap[self.size]
        self.size -= 1
        self.minHeapify(self.FRONT)
        return popped

    def get_min_value(self):
        return self.Heap[self.FRONT]

    def read_line(self):
        lines = []
        inputList = []
        with open('inputPS11.txt') as inputfile:
            lines = inputfile.readlines()

        for line in lines:
            startdt=line[1:11]
            enddt = line[13:23]
            arr = []
            #date(startdt[0:4], startdt[5:7], startdt[8:10])
            arr.append(datetime.strptime(startdt, '%Y-%m-%d').date())
            arr.append(datetime.strptime(enddt, '%Y-%m-%d').date())
            inputList.append(arr)
        print("Printing inputArray")
        print(inputList)
        return inputList

# Driver Code
if __name__ == "__main__":
    print('The minHeap is ')
    car = MinHeap(1000000)
    cap = 1

    #trips = [[date(2008, 10, 18), date(2008, 11, 19)], [date(2008, 11, 20), date(2008, 11, 21)], [date(2008, 2, 28), date(2008, 10, 19)], [date(2008, 11, 30), date(2009, 2, 10)]]
    #trips = [[date(2008, 10, 18), date(2008, 11, 19)], [date(2008, 11, 1), date(2008, 11, 21)], [date(2008, 2, 28), date(2008, 11, 19)], [date(2008, 1, 28), date(2008, 12, 19)], [date(2008, 1, 30), date(2009, 2, 10)]]
    #print(trips)
    y = car.read_line()
    x = y
    print(x)
    #correctArr = [[date(2008, 10, 18), date(2008, 11, 19)], [date(2008, 11, 1), date(2008, 11, 21)], [date(2008, 2, 28), date(2008, 11, 19)], [date(2008, 1, 28), date(2008, 12, 19)], [date(2008, 1, 30), date(2009, 2, 10)]]
    #print(correctArr)
    car.insert(x[0][1])
    car.Print()
    for s, e in x[1:]:
        print("S is " + str(s))
        print("E is " + str(e))
        #car.minHeap()
        if s > car.get_min_value():
            car.remove()
            car.Print()
            print("Inside IF block")
        else:
            cap = cap + 1
            print("Inside ELSE block")
        car.insert(e)
        car.Print()
    print("Cap is " + str(cap))
    outputFile = open('outputPS11.txt', 'w')
    outputFile.write("Cars - " + str(cap))



